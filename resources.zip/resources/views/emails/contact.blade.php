
You received a message from : {{ $data['firstName'] }}

<p>
Name: {{ $data['lastName'] }}
</p>

<p>
Email: {{ $data['email'] }}
</p>

<p>
Message: {{ $data['message'] }}
</p>
