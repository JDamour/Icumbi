Hello Dear Sir/Madam,
<p>House booking has been successful. Click on the link below to view house details.</p>
<p><a href="{{ $link }}" target="_blank">View house details</a></p>
<p>Thank you for working with us.</p>
<p>Best Regards.</p>
<br/>
<p>Icumbi Team</p>