@extends('layouts.user')
@section('title', 'add house')
@section('content')
@endsection
